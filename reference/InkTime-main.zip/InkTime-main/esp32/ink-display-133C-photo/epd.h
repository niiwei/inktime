/**
  ******************************************************************************
  * @file    epd.h
  * @author  Waveshare Team
  * @version V1.0.0
  * @date    23-January-2018
  * @brief   This file provides e-Paper driver functions
  *           void EPD_SendCommand(byte command);
  *           void EPD_SendData(byte data);
  *           void EPD_WaitUntilIdle();
  *           void EPD_Send_1(byte c, byte v1);
  *           void EPD_Send_2(byte c, byte v1, byte v2);
  *           void EPD_Send_3(byte c, byte v1, byte v2, byte v3);
  *           void EPD_Send_4(byte c, byte v1, byte v2, byte v3, byte v4);
  *           void EPD_Send_5(byte c, byte v1, byte v2, byte v3, byte v4, byte v5);
  *           void EPD_Reset();
  *           void EPD_dispInit();
  *           
  *          varualbes:
  *           EPD_dispLoad;                - pointer on current loading function
  *           EPD_dispIndex;               - index of current e-Paper
  *           EPD_dispInfo EPD_dispMass[]; - array of e-Paper properties
  *           
  ******************************************************************************
  */
#include <SPI.h>

/* SPI pin definition --------------------------------------------------------*/
// #if defined(CONFIG_IDF_TARGET_ESP32)
// #define PIN_SPI_SCK  13
// #define PIN_SPI_DIN  14
// #define PIN_SPI_CS   15
// #define PIN_SPI_BUSY 25
// #define PIN_SPI_RST  26
// #define PIN_SPI_DC   27
// #define PIN_SPI_CS_S 2
// #define PIN_SPI_CS_M 15
// #define PIN_SPI_PWR  32
// #else
// #define PIN_SPI_SCK  9
// #define PIN_SPI_DIN  10
// #define PIN_SPI_CS   6
// #define PIN_SPI_BUSY 17
// #define PIN_SPI_RST  18
// #define PIN_SPI_DC   8
// #define PIN_SPI_CS_S 7
// #define PIN_SPI_CS_M 6
// #define PIN_SPI_PWR  5
// #endif


#define _32s    //_32s    _32s3
#ifdef _32s
// SPI引脚定义（墨水屏）
#define PIN_SPI_PWR     32
#define PIN_SPI_BUSY   25
#define PIN_SPI_RST   26
#define PIN_SPI_DC    27
#define PIN_SPI_CS_S    2
#define PIN_SPI_CS_M    15
#define PIN_SPI_CS   15
#define PIN_SPI_SCK  13
#define PIN_SPI_DIN  14
//蜂鸣器
#define BEEP  12//PWM高电平起作用，默认拉低
// 按键定义
#define KEY_UP    34
#define KEY_MID   35
#define KEY_DOWN  0
// TF卡（SD卡）SPI引脚定义（如使用SPI模式）
#define PIN_TF_CS      5   // SD卡片选
#define PIN_TF_MOSI    23  // SD卡MOSI
#define PIN_TF_SCK     18  // SD卡SCK
#define PIN_TF_MISO    19  // SD卡MISO
//定义蓝色led引脚
#define PIN_BLUE_LED    2 //blue LED


#else    //_32s3
// SPI引脚定义（墨水屏）
#define PIN_SPI_PWR     12//32
#define PIN_SPI_BUSY 17//25
#define PIN_SPI_RST  18//26
#define PIN_SPI_DC   8//27
#define PIN_SPI_CS_S    16//33
#define PIN_SPI_CS_M    47//15
#define PIN_SPI_CS   47//15
#define PIN_SPI_SCK  9//13
#define PIN_SPI_DIN  19//14
//蜂鸣器
#define BEEP  20//PWM高电平起作用，默认拉低
// 按键定义
#define KEY_UP    6//34
#define KEY_MID   7//35
#define KEY_DOWN  0
// TF卡（SD卡）SPI引脚定义（如使用SPI模式）
#define PIN_TF_CS      38//5   // SD卡片选
#define PIN_TF_MOSI    39//23  // SD卡MOSI
#define PIN_TF_SCK     40//18  // SD卡SCK
#define PIN_TF_MISO    41//19  // SD卡MISO
//定义蓝色led引脚
#define PIN_BLUE_LED     48  //blue LED
#endif

/* Pin level definition ------------------------------------------------------*/
#define LOW             0
#define HIGH            1

#define GPIO_PIN_SET   1
#define GPIO_PIN_RESET 0

SPIClass vspi(HSPI);

void EPD_initSPI()
{
      // 按键初始化
    pinMode(KEY_UP, INPUT_PULLUP);
    pinMode(KEY_MID, INPUT_PULLUP);
    pinMode(KEY_DOWN, INPUT_PULLUP);
    //蜂鸣器引脚初始化
    pinMode(BEEP , OUTPUT);  
    // 蓝色LED引脚初始化
    pinMode(PIN_BLUE_LED , OUTPUT);
    // e-Paper initialization
    pinMode(PIN_SPI_BUSY,  INPUT);
    pinMode(PIN_SPI_RST , OUTPUT);
    pinMode(PIN_SPI_DC  , OUTPUT);
    
    pinMode(PIN_SPI_SCK, OUTPUT);
    pinMode(PIN_SPI_DIN, OUTPUT);
    pinMode(PIN_SPI_CS , OUTPUT);

    pinMode(PIN_SPI_CS_S , OUTPUT);
    pinMode(PIN_SPI_PWR , OUTPUT);  //外设电源

    //默认值
    digitalWrite(PIN_SPI_CS, HIGH);
    digitalWrite(PIN_SPI_CS_S, LOW);         //ESP32S的话，修改为0，即可关闭蓝色LED
    digitalWrite(PIN_SPI_PWR, HIGH);         //打开外设供电
    digitalWrite(PIN_SPI_SCK, LOW);
    digitalWrite(BEEP, 0);                   //蜂鸣器默认关闭 
    digitalWrite(PIN_BLUE_LED, 0);           //蓝色LED灭
    vspi.begin(PIN_SPI_SCK, -1, PIN_SPI_DIN, -1);
}

void GPIO_Mode(unsigned char GPIO_Pin, unsigned char Mode)
{
    if(Mode == 0) {
        pinMode(GPIO_Pin , INPUT);
	} else {
		pinMode(GPIO_Pin , OUTPUT);
	}
}

/* Lut mono ------------------------------------------------------------------*/
byte lut_full_mono[] =
{
    0x02, 0x02, 0x01, 0x11, 0x12, 0x12, 0x22, 0x22, 
    0x66, 0x69, 0x69, 0x59, 0x58, 0x99, 0x99, 0x88, 
    0x00, 0x00, 0x00, 0x00, 0xF8, 0xB4, 0x13, 0x51, 
    0x35, 0x51, 0x51, 0x19, 0x01, 0x00
};

byte lut_partial_mono[] =
{
    0x10, 0x18, 0x18, 0x08, 0x18, 0x18, 0x08, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x13, 0x14, 0x44, 0x12, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00
};

/* The procedure of sending a byte to e-Paper by SPI -------------------------*/
void EpdSpiTransferCallback(byte data) 
{
    //SPI.beginTransaction(spi_settings);
    digitalWrite(PIN_SPI_CS, GPIO_PIN_RESET);

    for (int i = 0; i < 8; i++)
    {
        digitalWrite(PIN_SPI_DIN, ((data & 0x80) == 0 ? GPIO_PIN_RESET : GPIO_PIN_SET));
        data <<= 1;
        digitalWrite(PIN_SPI_SCK, GPIO_PIN_SET);
        digitalWrite(PIN_SPI_SCK, GPIO_PIN_RESET);
    }
    
    //SPI.transfer(data);
    digitalWrite(PIN_SPI_CS, GPIO_PIN_SET);
    //SPI.endTransaction();
}


unsigned char DEV_SPI_ReadByte()
{
    unsigned char j=0xff;
    GPIO_Mode(PIN_SPI_DIN, 0);
    digitalWrite(PIN_SPI_CS, GPIO_PIN_RESET);
    for (int i = 0; i < 8; i++)
    {
        j = j << 1;
        if (digitalRead(PIN_SPI_DIN))  j = j | 0x01;
        else                            j = j & 0xfe;
        
        digitalWrite(PIN_SPI_SCK, GPIO_PIN_SET);     
        digitalWrite(PIN_SPI_SCK, GPIO_PIN_RESET);
    }
    digitalWrite(PIN_SPI_CS, GPIO_PIN_SET);
    GPIO_Mode(PIN_SPI_DIN, 1);
    return j;
}

byte lut_vcom0[] = { 15, 0x0E, 0x14, 0x01, 0x0A, 0x06, 0x04, 0x0A, 0x0A, 0x0F, 0x03, 0x03, 0x0C, 0x06, 0x0A, 0x00 };
byte lut_w    [] = { 15, 0x0E, 0x14, 0x01, 0x0A, 0x46, 0x04, 0x8A, 0x4A, 0x0F, 0x83, 0x43, 0x0C, 0x86, 0x0A, 0x04 };
byte lut_b    [] = { 15, 0x0E, 0x14, 0x01, 0x8A, 0x06, 0x04, 0x8A, 0x4A, 0x0F, 0x83, 0x43, 0x0C, 0x06, 0x4A, 0x04 };
byte lut_g1   [] = { 15, 0x8E, 0x94, 0x01, 0x8A, 0x06, 0x04, 0x8A, 0x4A, 0x0F, 0x83, 0x43, 0x0C, 0x06, 0x0A, 0x04 };
byte lut_g2   [] = { 15, 0x8E, 0x94, 0x01, 0x8A, 0x06, 0x04, 0x8A, 0x4A, 0x0F, 0x83, 0x43, 0x0C, 0x06, 0x0A, 0x04 };
byte lut_vcom1[] = { 15, 0x03, 0x1D, 0x01, 0x01, 0x08, 0x23, 0x37, 0x37, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 };
byte lut_red0 [] = { 15, 0x83, 0x5D, 0x01, 0x81, 0x48, 0x23, 0x77, 0x77, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 };
byte lut_red1 [] = { 15, 0x03, 0x1D, 0x01, 0x01, 0x08, 0x23, 0x37, 0x37, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 };

/* Sending a byte as a command -----------------------------------------------*/
void EPD_SendCommand(byte command) 
{
    digitalWrite(PIN_SPI_DC, LOW);
    EpdSpiTransferCallback(command);
}

void EPD_SendCommand_13in3E6(byte command) 
{
    digitalWrite(PIN_SPI_DC, LOW);
    vspi.beginTransaction(SPISettings(10000000, MSBFIRST, SPI_MODE0));
    vspi.transfer(command);
    vspi.endTransaction();
}

/* Sending a byte as a data --------------------------------------------------*/
void EPD_SendData(byte data) 
{
    digitalWrite(PIN_SPI_DC, HIGH);
    EpdSpiTransferCallback(data);
}

void EPD_SendData_13in3E6(byte data) 
{
    digitalWrite(PIN_SPI_DC, HIGH);
    vspi.beginTransaction(SPISettings(10000000, MSBFIRST, SPI_MODE0));
    vspi.transfer(data);
    vspi.endTransaction();
}

/* Waiting the e-Paper is ready for further instructions ---------------------*/
void EPD_WaitUntilIdle() 
{
    //0: busy, 1: idle
    while(digitalRead(PIN_SPI_BUSY) == 0) delay(100);    
}

/* Waiting the e-Paper is ready for further instructions ---------------------*/
void EPD_WaitUntilIdle_high() 
{
    //1: busy, 0: idle
    while(digitalRead(PIN_SPI_BUSY) == 1) delay(100);    
}

/* Send a one-argument command -----------------------------------------------*/
void EPD_Send_1(byte c, byte v1)
{
    EPD_SendCommand(c);
    EPD_SendData(v1);
}

/* Send a two-arguments command ----------------------------------------------*/
void EPD_Send_2(byte c, byte v1, byte v2)
{
    EPD_SendCommand(c);
    EPD_SendData(v1);
    EPD_SendData(v2);
}

/* Send a three-arguments command --------------------------------------------*/
void EPD_Send_3(byte c, byte v1, byte v2, byte v3)
{
    EPD_SendCommand(c);
    EPD_SendData(v1);
    EPD_SendData(v2);
    EPD_SendData(v3);
}

/* Send a four-arguments command ---------------------------------------------*/
void EPD_Send_4(byte c, byte v1, byte v2, byte v3, byte v4)
{
    EPD_SendCommand(c);
    EPD_SendData(v1);
    EPD_SendData(v2);
    EPD_SendData(v3);
    EPD_SendData(v4);
}

/* Send a five-arguments command ---------------------------------------------*/
void EPD_Send_5(byte c, byte v1, byte v2, byte v3, byte v4, byte v5)
{
    EPD_SendCommand(c);
    EPD_SendData(v1);
    EPD_SendData(v2);
    EPD_SendData(v3);
    EPD_SendData(v4);
    EPD_SendData(v5);
}

/* Writting lut-data into the e-Paper ----------------------------------------*/
void EPD_lut(byte c, byte l, byte*p)
{
    // lut-data writting initialization
    EPD_SendCommand(c);

    // lut-data writting doing
    for (int i = 0; i < l; i++, p++) EPD_SendData(*p);
}

/* Writting lut-data of the black-white channel ------------------------------*/
void EPD_SetLutBw(byte*c20, byte*c21, byte*c22, byte*c23, byte*c24) 
{
    EPD_lut(0x20, *c20, c20 + 1);//g vcom 
    EPD_lut(0x21, *c21, c21 + 1);//g ww -- 
    EPD_lut(0x22, *c22, c22 + 1);//g bw r
    EPD_lut(0x23, *c23, c23 + 1);//g wb w
    EPD_lut(0x24, *c24, c24 + 1);//g bb b
}

/* Writting lut-data of the red channel --------------------------------------*/
void EPD_SetLutRed(byte*c25, byte*c26, byte*c27) 
{
    EPD_lut(0x25, *c25, c25 + 1);
    EPD_lut(0x26, *c26, c26 + 1);
    EPD_lut(0x27, *c27, c27 + 1);
}

/* This function is used to 'wake up" the e-Paper from the deep sleep mode ---*/
void EPD_Reset() 
{
    digitalWrite(PIN_SPI_RST, HIGH); 
    delay(200);    
    digitalWrite(PIN_SPI_RST, LOW);    
    delay(2);
    digitalWrite(PIN_SPI_RST, HIGH); 
    delay(200);    
}

/* e-Paper initialization functions ------------------------------------------*/ 
#include "epd1in54.h"
#include "epd2in13.h"
#include "epd2in9.h"
#include "epd2in7.h"
#include "epd2in66.h"
#include "epd3in7.h"
#include "epd3in52.h"
#include "epd4in01f.h"
#include "epd4in26.h"
#include "epd5in65f.h"
#include "epd5in83.h"
#include "epd7in3.h"
#include "epd7in5.h"
#include "epd7in5_HD.h"
#include "epd13in3.h"

bool EPD_invert;           // If true, then image data bits must be inverted
int  EPD_dispIndex;        // The index of the e-Paper's type
int  EPD_dispX, EPD_dispY; // Current pixel's coordinates (for 2.13 only)
void(*EPD_dispLoad)(const uint8_t*, size_t);     // Pointer on a image data writting function

/* Image data loading function for a-type e-Paper ----------------------------*/ 
void EPD_loadA(const uint8_t* s, size_t bytes)
{
    // Enumerate all of image data bytes
    for (int pos = 0; pos < bytes; ++pos)
    {
        // Get current byte
        uint8_t value = s[pos];
//		Serial.printf("address:%d, data:%x ",pos, value);
//		if(pos % 8 == 0)
//			Serial.printf("\r\n");
        // Invert byte's bits in case of '2.7' e-Paper
        if (EPD_invert) value = ~value;

        // Write the byte into e-Paper's memory
        EPD_SendData((byte)value);
    }
}

void EPD_loadAFilp(const uint8_t* s, size_t bytes)
{
    // Enumerate all of image data bytes
    for (int pos = 0; pos < bytes; ++pos)
    {
        // Get current byte
        uint8_t value = s[pos];
		
        // Invert byte's bits in case of '2.7' e-Paper
        if (EPD_invert) value = ~value;

        // Write the byte into e-Paper's memory
        EPD_SendData(~(byte)value);
    }
}

/* Image data loading function for b-type e-Paper ----------------------------*/
void EPD_loadB(const uint8_t* s, size_t bytes)
{
    // Enumerate all of image data bytes
    for (int pos = 0; pos + 1 < bytes; pos += 2)
    {
        // Get current word from obtained image data
        int valueA = (int)s[pos] + ((int)s[pos + 1] << 8);

        // Clean current word of processed image data 
        int valueB = 0;

        // Enumerate next 8 pixels
        for (int p = 0; p < 8; p++)
        {
            // Current obtained pixel data
            int pixInd = valueA & 3;

            // Remove the obtained pixel data from 'valueA' word
            valueA = valueA >> 2;

            // Processing of 8 2-bit pixels to 8 2-bit pixels: 
            // black(value 0) to bits 00, white(value 1) to bits 11, gray(otherwise) to bits 10
            valueB = (valueB << 2) + (pixInd == 1 ? 3 : (pixInd == 0 ? 0 : 2));
        }

        // Write the word into e-Paper's memory
        EPD_SendData((byte)(valueB >> 8));
        EPD_SendData((byte)valueB);
    }
}

/* Image data loading function for 2.13 e-Paper ------------------------------*/
void EPD_loadC(const uint8_t* s, size_t bytes)
{
    EPD_Send_2(0x44, 0, 15);        //SET_RAM_X_ADDRESS_START_END_POSITION LO(x >> 3), LO((w - 1) >> 3)
    EPD_Send_4(0x45, 0, 0, 249, 0); //SET_RAM_Y_ADDRESS_START_END_POSITION LO(y), HI(y), LO(h - 1), HI(h - 1)

    // Enumerate all of image data bytes
    for (int pos = 0; pos < bytes; ++pos)
    {
        // Before write a line of image data
        // 2.13 e-Paper requires to set the address counter
        // Every line has 15*8-6 pixels + 6 empty bits, totally 15*8 bits
        if (EPD_dispX == 0)
        {
            EPD_Send_1(0x4E, 0           );//SET_RAM_X_ADDRESS_COUNTER: LO(x >> 3)
            EPD_Send_2(0x4F, EPD_dispY, 0);//SET_RAM_Y_ADDRESS_COUNTER: LO(y), HI(y)  
            EPD_SendCommand(0x24);//WRITE_RAM
        }

        // Write the byte into e-Paper's memory
        EPD_SendData(s[pos]);

        // EPD_dispX and EPD_dispY increments
        if (++EPD_dispX > 15)
        {
            EPD_dispX = 0;

            // If the client's browser sends more bits, than it needs, then exit the function
            if (++EPD_dispY > 250) return;
        }
    }
}

/* Image data loading function for 7.5 e-Paper -------------------------------*/
void EPD_loadD(const uint8_t* s, size_t bytes)
{
    // Enumerate all of image data bytes
    for (int pos = 0; pos < bytes; ++pos)
    {
        // Get current byte from obtained image data
        uint8_t valueA = s[pos];

        // Processing of 4 1-bit pixels to 4 4-bit pixels:
        // black(value 0) to bits 0000, white(value 1) to bits 0011
        EPD_SendData((byte)((valueA & 0x80) ? 0x30 : 0x00) + ((valueA & 0x40) ? 0x03 : 0x00));
        EPD_SendData((byte)((valueA & 0x20) ? 0x30 : 0x00) + ((valueA & 0x10) ? 0x03 : 0x00));
        EPD_SendData((byte)((valueA & 0x08) ? 0x30 : 0x00) + ((valueA & 0x04) ? 0x03 : 0x00));
        EPD_SendData((byte)((valueA & 0x02) ? 0x30 : 0x00) + ((valueA & 0x01) ? 0x03 : 0x00));  
    }
}

/* Image data loading function for 7.5b e-Paper ------------------------------*/
void EPD_loadE(const uint8_t* s, size_t bytes)
{
    // Enumerate all of image data bytes
    for (int pos = 0; pos < bytes; ++pos)
    {
        // Get current byte from obtained image data
        uint8_t value = s[pos];

        // Processing of 4 1-bit pixels to 4 4-bit pixels:
        // red(value 1) to bits 0011, white(value 3) to bits 0100
        int A = (value     ) & 3;if (A == 3) A = 4;if (A == 1) A = 3;
        int B = (value >> 2) & 3;if (B == 3) B = 4;if (B == 1) B = 3;
        int C = (value >> 4) & 3;if (C == 3) C = 4;if (C == 1) C = 3;
        int D = (value >> 6) & 3;if (D == 3) D = 4;if (D == 1) D = 3;

        // Write the word into e-Paper's memory
        EPD_SendData((A << 4) + B);
        EPD_SendData((C << 4) + D);
    }
}

/* Image data loading function for 5.83b e-Paper -----------------------------*/
void EPD_loadF(const uint8_t* s, size_t bytes)
{
    // Enumerate all of image data bytes
    for (int pos = 0; pos + 1 < bytes; pos += 2)
    {
        // Get current byte from obtained image data
        uint8_t value = s[pos];
        uint8_t value1 = s[pos+1];
        // Processing of 4 1-bit pixels to 4 4-bit pixels:
        // white(value 1) to bits 0011, red(value 2) to bits 0100
        int A = (value     ) & 3;if (A == 2) A = 4;
        int B = (value >> 4) & 3;if (B == 2) B = 4; // Not sure why it was value>>8
        int C = (value1 >> 4) & 3;if (C == 2) C = 4;
        int D = (value1 >> 6) & 3;if (D == 2) D = 4;

        // Write the word into e-Paper's memory
        EPD_SendData((A << 4) + B);
        EPD_SendData((C << 4) + D);
    }
}

/* Image data loading function for 5.65f e-Paper -----------------------------*/
void EPD_loadG(const uint8_t* s, size_t bytes)
{
    // Enumerate all of image data bytes
    for (int pos = 0; pos < bytes; ++pos)
    {
        // Get current byte from obtained image data
        uint8_t value = s[pos];
		
        // Switch the positions of the two 4-bits pixels
        uint8_t A = (value     ) & 0x07;
        uint8_t B = (value >> 4) & 0x07;
		
        // Write the data into e-Paper's memory
        EPD_SendData((A << 4) + B);
    }
}

void EPD_load_13in3E6(const uint8_t* s, size_t bytes)
{
    digitalWrite(PIN_SPI_DC, HIGH);
    vspi.beginTransaction(SPISettings(10000000, MSBFIRST, SPI_MODE0));
    // Enumerate all of image data bytes - direct bulk transfer
    for (int pos = 0; pos < bytes; ++pos)
    {
        // Get current byte from obtained image data
        uint8_t value = s[pos];
        // Switch the positions of the two 4-bits pixels
        uint8_t A = (value     ) & 0x07;
        uint8_t B = (value >> 4) & 0x07;
        // Write the data into e-Paper's memory - direct transfer without toggling CS
        vspi.transfer((A << 4) + B);
    }
    vspi.endTransaction();
}

/* Show image and turn to deep sleep mode (a-type, 4.2 and 2.7 e-Paper) ------*/
void EPD_showA() 
{
    // Refresh
    EPD_Send_1(0x22, 0xC4);// DISPLAY_UPDATE_CONTROL_2
    EPD_SendCommand( 0x20);// MASTER_ACTIVATION
    EPD_SendCommand( 0xFF);// TERMINATE_FRAME_READ_WRITE
    EPD_WaitUntilIdle();

    // Sleep
    EPD_SendCommand(0x10);// DEEP_SLEEP_MODE
    EPD_WaitUntilIdle();
}

/* Show image and turn to deep sleep mode (b-type, e-Paper) ------------------*/
void EPD_showB() 
{
    // Refresh
    EPD_SendCommand(0x12);// DISPLAY_REFRESH
    delay(100);
    EPD_WaitUntilIdle();

    // Sleep
    EPD_Send_1(0x50, 0x17);// VCOM_AND_DATA_INTERVAL_SETTING
    EPD_Send_1(0x82, 0x00);// VCM_DC_SETTING_REGISTER, to solve Vcom drop
    EPD_Send_4(0x01, 0x02, 0x00, 0x00, 0x00);// POWER_SETTING
    EPD_WaitUntilIdle();
    EPD_SendCommand(0x02);// POWER_OFF
}

/* Show image and turn to deep sleep mode (7.5 and 7.5b e-Paper) -------------*/
void EPD_showC() 
{
    // Refresh
    EPD_SendCommand(0x12);// DISPLAY_REFRESH
    delay(100);
    EPD_WaitUntilIdle();

    // Sleep
    EPD_SendCommand(0x02);// POWER_OFF
    EPD_WaitUntilIdle();
    EPD_Send_1(0x07, 0xA5);// DEEP_SLEEP
}

void EPD_showD()
{
    // VCOM AND DATA INTERVAL SETTING
    // WBmode:VBDF 17, D7 VBDW 97, VBDB 57
    // WBRmode:VBDF F7, VBDW 77, VBDB 37, VBDR B7
    EPD_Send_1(0x50, 0x97);

    EPD_SendCommand(0x20);
    for(int count=0; count<44; count++) EPD_SendData(lut_vcomDC_2in13d[count]);
    
    EPD_SendCommand(0x21);
    for(int count=0; count<42; count++) EPD_SendData(lut_ww_2in13d[count]);

    EPD_SendCommand(0x22);
    for(int count=0; count<42; count++) EPD_SendData(lut_bw_2in13d[count]);
    
    EPD_SendCommand(0x23);
    for(int count=0; count<42; count++) EPD_SendData(lut_wb_2in13d[count]);
    
    EPD_SendCommand(0x24);
    for(int count=0; count<42; count++) EPD_SendData(lut_bb_2in13d[count]);

    delay(10);
    EPD_SendCommand(0x12);//DISPLAY REFRESH
    delay(100);     //!!!The delay here is necessary, 200uS at least!!!
    EPD_WaitUntilIdle(); 

    EPD_Send_1(0x50, 0xf7);
    EPD_SendCommand( 0x02);//POWER_OFF
    EPD_Send_1(0x07, 0xA5);//DEEP_SLEEP
}

#include "epd4in2.h"

/* The set of pointers on 'init', 'load' and 'show' functions, title and code */
struct EPD_dispInfo
{
    int(*init)(); // Initialization
    void(*chBk)(const uint8_t*, size_t);// Black channel loading
    int next;     // Change channel code
    void(*chRd)(const uint8_t*, size_t);// Red channel loading
    void(*show)();// Show and sleep
    char*title;   // Title of an e-Paper
};

/* Array of sets describing the usage of e-Papers ----------------------------*/
EPD_dispInfo EPD_dispMass[] =
{
    { EPD_Init_1in54,		EPD_loadA,		-1  ,	0,				EPD_1IN54_Show,		"1.54 inch"		},// a 0
    { EPD_Init_1in54b,		EPD_loadB,		0x13,	EPD_loadA,		EPD_showB,			"1.54 inch b"	},// b 1
    { EPD_Init_1in54c,		EPD_loadA,		0x13,	EPD_loadA,		EPD_showB,			"1.54 inch c"	},// c 2
    { EPD_Init_2in13,		EPD_loadC,		-1  ,	0,				EPD_showA,			"2.13 inch"		},// d 3
    { EPD_Init_2in13b,		EPD_loadA,		0x13,	EPD_loadA,		EPD_showB,			"2.13 inch b"	},// e 4
    { EPD_Init_2in13b,		EPD_loadA,		0x13,	EPD_loadA,		EPD_showB,			"2.13 inch c"	},// f 5
    { EPD_Init_2in13d,		EPD_loadA,		-1  ,	0,				EPD_showD,			"2.13 inch d"	},// g 6
    { EPD_Init_2in7,		EPD_loadA, 		1  ,	0,				EPD_showB,			"2.7 inch"		},// h 7
    { EPD_Init_2in7b,		EPD_loadA,		0x13,	EPD_loadA,		EPD_showB,			"2.7 inch b"	},// i 8
    { EPD_Init_2in9,		EPD_loadA,		-1  ,	0,				EPD_showA,			"2.9 inch"		},// j 9
    { EPD_Init_2in9b,		EPD_loadA,		0x13,	EPD_loadA,		EPD_showB,			"2.9 inch b"	},// k 10
    { EPD_Init_2in9b,		EPD_loadA,		0x13,	EPD_loadA,		EPD_showB,			"2.9 inch c"	},// l 11
    { EPD_Init_2in9d,		EPD_loadA,		-1  ,	0,				EPD_2IN9D_Show,		"2.9 inch d"	},// M 12
    { EPD_Init_4in2,		EPD_loadA,		-1  ,	0,				EPD_showB,			"4.2 inch"		},// N 13
    { EPD_Init_4in2b,		EPD_loadA,		0x13,	EPD_loadA,		EPD_showB,  		"4.2 inch b"	},// O 14
    { EPD_Init_4in2b,		EPD_loadA,		0x13,	EPD_loadA,		EPD_showB,			"4.2 inch c"	},// P 15
    { EPD_5in83__init,		EPD_loadD,		-1  ,	0,				EPD_showC,			"5.83 inch"		},// Q 16
    { EPD_5in83b__init,		EPD_loadE,		-1  ,	0,				EPD_showC,			"5.83 inch b"	},// R 17
    { EPD_5in83b__init,		EPD_loadE,		-1  ,	0,				EPD_showC,			"5.83 inch c"	},// S 18
    { EPD_7in5__init,		EPD_loadD,		-1  ,	0,				EPD_showC,			"7.5 inch"		},// T 19    
    { EPD_7in5__init,		EPD_loadE,		-1  ,	0,				EPD_showC,			"7.5 inch b"	},// u 20
    { EPD_7in5__init,		EPD_loadE,		-1  ,	0,				EPD_showC,			"7.5 inch c"	},// v 21
    { EPD_7in5_V2_init,		EPD_loadAFilp,	-1  ,	0,				EPD_7IN5_V2_Show,	"7.5 inch V2"	},// w 22
    { EPD_7in5B_V2_Init,	EPD_loadA,		0x13,	EPD_loadAFilp,	EPD_7IN5_V2_Show,	"7.5 inch B V2"	},// x 23
    { EPD_7IN5B_HD_init,	EPD_loadA,		0x26,	EPD_loadAFilp,	EPD_7IN5B_HD_Show,	"7.5 inch B HD"	},// y 24
	{ EPD_5IN65F_init,		EPD_loadG,		-1  ,	0,				EPD_5IN65F_Show,	"5.65 inch F "	},// z 25
	{ EPD_7IN5_HD_init,		EPD_loadA,		-1	,	0,				EPD_7IN5_HD_Show,	"7.5 inch HD"	},// A 26
	{ EPD_3IN7_1Gray_Init,	EPD_loadA,		-1	,	0,				EPD_3IN7_1Gray_Show,"3.7 inch"		},// 27
	{ EPD_2IN66_Init,		EPD_loadA,		-1	,	0,				EPD_2IN66_Show,		"2.66 inch"		},// 28
	{ EPD_5in83b_V2_init,	EPD_loadA,		0x13,	EPD_loadAFilp,	EPD_showC,			"5.83 inch B V2"},// 29
	{ EPD_Init_2in9b_V3,	EPD_loadA,		0x13,	EPD_loadA,		EPD_showC,			"2.9 inch B V3"	},// 30
	{ EPD_1IN54B_V2_Init,	EPD_loadA,		0x26,	EPD_loadAFilp,	EPD_1IN54B_V2_Show,	"1.54 inch B V2"},// 31
	{ EPD_2IN13B_V3_Init,	EPD_loadA,		0x13,	EPD_loadA,		EPD_2IN13B_V3_Show,	"2.13 inch B V3"},// 32
	{ EPD_Init_2in9_V2, 	EPD_loadA,		-1,		0,				EPD_2IN9_V2_Show,	"2.9 inch V2"	},// 33
	{ EPD_Init_4in2b_V2,	EPD_loadA,		-1  ,	EPD_4IN2B_V2_load,EPD_4IN2B_V2_Show,"4.2 inch b V2"	},// 34
	{ EPD_2IN66B_Init,		EPD_loadA,		0x26,	EPD_loadAFilp,	EPD_2IN66_Show,		"2.66 inch b"	},// 35
	{ EPD_Init_5in83_V2,	EPD_loadAFilp,	-1,		0,				EPD_showC,			"5.83 inch V2"	},// 36
	{ EPD_4IN01F_init,		EPD_loadG,		-1,		0,				EPD_4IN01F_Show,	"4.01 inch f"	},// 37
	{ EPD_Init_2in7b_V2,	EPD_loadA,		0x26,	EPD_loadAFilp,	EPD_Show_2in7b_V2,	"2.7 inch B V2"	},// 38
	{ EPD_Init_2in13_V3,	EPD_loadC,		-1, 	0, 				EPD_2IN13_V3_Show, 	"2.13 inch V3"	},// 39
	{ EPD_2IN13B_V4_Init,	EPD_loadA,		0x26,	EPD_loadA,		EPD_2IN13B_V4_Show, "2.13 inch B V4"},// 40
    { EPD_3IN52_Init,	    EPD_loadA,		-1,	    0,		        EPD_3IN52_Show,     "3.52 inch"     },// 41
    { EPD_2IN7_V2_Init,		EPD_loadA, 		-1  ,	0,				EPD_2IN7_V2_Show,	"2.7 inch V2"	},// 42
    { EPD_Init_2in13_V4,	EPD_loadC, 		-1  ,	0,				EPD_2IN13_V4_Show,	"2.13 inch V4"	},// 43
    { EPD_Init_4in2_V2,	    EPD_loadA, 		-1  ,	0,				EPD_4IN2_V2_Show,	"4.2 inch V2"	},// 44
    { EPD_13in3k_init,	    EPD_loadA, 		-1  ,	0,				EPD_13in3k_Show,	"13.3 inch K"	},// 45
    { EPD_4in26_init,	    EPD_loadA, 		-1  ,	0,				EPD_4in26_Show,	    "4.26 inch"	    },// 46
    { EPD_Init_2in9b_V4,    EPD_loadA, 		0x26,	EPD_loadAFilp,	EPD_2in9b_V4_Show,	"2.9 inch b V4" },// 47
    { EPD_13in3b_init,      EPD_loadA, 		0x26,	EPD_loadAFilp,	EPD_13in3b_Show ,	"13.3 inch b"   },// 48
    { EPD_7in3E_init,       EPD_loadG, 		-1,	    0,	            EPD_7in3E_Show ,	"7.3 inch E"    },// 49
    { EPD_13in3E_init,      EPD_load_13in3E6, -1,   EPD_load_13in3E6, EPD_13in3E_Show , "13.3 inch E"   },// 50
};

/* Initialization of an e-Paper ----------------------------------------------*/
void EPD_dispInit()
{
    // Call initialization function
    EPD_dispMass[EPD_dispIndex].init();

    // Set loading function for black channel
    EPD_dispLoad = EPD_dispMass[EPD_dispIndex].chBk;

    // Set initial coordinates
    EPD_dispX = 0;
    EPD_dispY = 0;

    // The inversion of image data bits isn't needed by default
    EPD_invert = false;
}
